

//app/layout

import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Space_Grotesk } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' })
const spaceGrotesk = Space_Grotesk({ subsets: ['latin'], variable: '--font-space-grotesk', display: 'swap' })

export const metadata: Metadata = {
  title: 'GraphShield — Intelligent Document Forensics & Plagiarism Detection',
  description:
    'GraphShield analyzes PDF documents for text similarity, visual duplication, duplicated figures, and suspicious content with AI-powered forensic analysis.',
  generator: 'v0.app',
}

export const viewport: Viewport = { colorScheme: 'dark', themeColor: '#0b1220' }

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`dark bg-background ${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}

//app/page
import { SiteNav } from '@/components/site-nav'
import { Hero } from '@/components/hero'
import { Features } from '@/components/features'
import { HowItWorks } from '@/components/how-it-works'
import { CallToAction } from '@/components/cta'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <div className="min-h-screen bg-background">
      <SiteNav />
      <main>
        <Hero />
        <Features />
        <HowItWorks />
        <CallToAction />
      </main>
      <SiteFooter />
    </div>
  )
}

//components/logo
import { cn } from '@/lib/utils'

export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn('flex items-center gap-2.5', className)}>
      <span className="relative grid size-9 place-items-center rounded-lg border border-primary/30 bg-primary/10 shadow-[0_0_20px_-6px_var(--color-primary)]">
        <svg viewBox="0 0 24 24" fill="none" className="size-5 text-primary" aria-hidden="true">
          <path d="M12 2.5 4 5.5v5.2c0 4.7 3.2 8.4 8 10.8 4.8-2.4 8-6.1 8-10.8V5.5l-8-3Z"
            stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
          <circle cx="9.2" cy="10" r="1.4" fill="currentColor" />
          <circle cx="15" cy="8.4" r="1.2" fill="currentColor" />
          <circle cx="14.4" cy="14" r="1.3" fill="currentColor" />
          <path d="M9.2 10 15 8.4M9.2 10l5.2 4M15 8.4l-.6 5.6"
            stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" />
        </svg>
      </span>
      <span className="font-heading text-lg font-semibold tracking-tight">
        Graph<span className="text-primary">Shield</span>
      </span>
    </span>
  )
}

//components/site-nav
'use client'

import { useState } from 'react'
import { Menu, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Logo } from '@/components/logo'

const links = [
  { label: 'Home', href: '#home' },
  { label: 'Features', href: '#features' },
  { label: 'How It Works', href: '#how-it-works' },
  { label: 'About', href: '#about' },
]

export function SiteNav() {
  const [open, setOpen] = useState(false)

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
        <a href="#home" aria-label="GraphShield home"><Logo /></a>

        <ul className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <li key={link.href}>
              <a href={link.href} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden md:block">
          <Button nativeButton={false} render={<a href="#cta" />}
            className="h-9 px-4 shadow-[0_0_24px_-8px_var(--color-primary)]">
            Get Started
          </Button>
        </div>

        <button type="button" onClick={() => setOpen((v) => !v)}
          className="grid size-9 place-items-center rounded-lg border border-border text-foreground md:hidden"
          aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open}>
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-border/60 bg-background/95 px-6 py-4 md:hidden">
          <ul className="flex flex-col gap-1">
            {links.map((link) => (
              <li key={link.href}>
                <a href={link.href} onClick={() => setOpen(false)}
                  className="block rounded-lg px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <Button nativeButton={false} render={<a href="#cta" />} onClick={() => setOpen(false)}
            className="mt-3 h-10 w-full">
            Get Started
          </Button>
        </div>
      )}
    </header>
  )
}

//components/hero
import Image from 'next/image'
import { ArrowRight, ShieldCheck, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden px-6 pt-32 pb-20 md:pt-40 md:pb-28">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-primary/15 blur-[130px]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,var(--color-background)_75%)]" />
      </div>

      <div className="mx-auto grid max-w-6xl items-center gap-14 lg:grid-cols-[1.05fr_0.95fr]">
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-3.5 py-1.5 text-xs font-medium text-primary">
            <Sparkles className="size-3.5" />
            AI-Powered Document Forensics
          </span>

          <h1 className="mt-6 font-heading text-4xl font-semibold leading-[1.08] tracking-tight text-balance sm:text-5xl md:text-6xl">
            Protecting Original Work with Intelligent Analysis.
          </h1>

          <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
            GraphShield analyzes your PDF documents for text similarity, visual
            duplication, duplicated figures, and suspicious content — delivering
            forensic-grade insight you can trust.
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button nativeButton={false} render={<a href="#cta" />}
              className="h-12 gap-2 px-6 text-sm shadow-[0_0_30px_-8px_var(--color-primary)]">
              Analyze a Document <ArrowRight className="size-4" />
            </Button>
            <Button variant="outline" nativeButton={false} render={<a href="#features" />}
              className="h-12 px-6 text-sm">
              Explore Features
            </Button>
          </div>

          <div className="mt-10 flex items-center gap-6 text-sm text-muted-foreground">
            <span className="flex items-center gap-2"><ShieldCheck className="size-4 text-primary" /> Forensic-grade accuracy</span>
            <span className="hidden items-center gap-2 sm:flex"><ShieldCheck className="size-4 text-primary" /> Private &amp; secure</span>
          </div>
        </div>

        <div className="animate-fade-up [animation-delay:150ms]">
          <div className="relative rounded-2xl border border-border/70 bg-card/60 p-2 shadow-2xl backdrop-blur-xl">
            <div className="relative overflow-hidden rounded-xl">
              <Image src="/hero-analysis.png"
                alt="GraphShield analyzing a PDF document with an overlaid similarity graph"
                width={720} height={720} priority className="h-auto w-full" />
              <div aria-hidden="true"
                className="animate-sweep pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-primary/40 via-primary/10 to-transparent" />
            </div>
            <div className="absolute -bottom-5 -left-4 hidden rounded-xl border border-border/70 bg-background/90 px-4 py-3 backdrop-blur-xl sm:block">
              <p className="text-xs text-muted-foreground">Risk Score</p>
              <p className="font-heading text-xl font-semibold text-primary">Low · 12%</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

//components/features
import { FileSearch, Images, Gauge, FileText } from 'lucide-react'

const features = [
  { icon: FileSearch, title: 'Text Similarity Detection', description: 'Deep semantic comparison uncovers paraphrased passages and near-duplicate text across billions of reference sources.' },
  { icon: Images, title: 'Visual & Figure Analysis', description: 'Detects duplicated, reused, or manipulated figures, charts, and images embedded within your documents.' },
  { icon: Gauge, title: 'Intelligent Risk Scoring', description: 'A single, explainable risk score weighs every signal so you can prioritize what actually matters.' },
  { icon: FileText, title: 'Detailed Forensic Reports', description: 'Export clear, evidence-backed reports with highlighted matches, sources, and confidence levels.' },
]

export function Features() {
  return (
    <section id="features" className="scroll-mt-20 px-6 py-20 md:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-medium text-primary">Capabilities</span>
          <h2 className="mt-3 font-heading text-3xl font-semibold tracking-tight text-balance md:text-4xl">
            A complete forensic toolkit for document integrity
          </h2>
          <p className="mt-4 text-muted-foreground text-pretty">
            Every layer of analysis works together to surface plagiarism and manipulation with precision.
          </p>
        </div>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <div key={feature.title}
              className="group relative rounded-2xl border border-border/70 bg-card/50 p-6 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:bg-card/80">
              <div className="grid size-11 place-items-center rounded-xl border border-primary/25 bg-primary/10 text-primary transition-colors group-hover:bg-primary/15">
                <feature.icon className="size-5" />
              </div>
              <h3 className="mt-5 font-heading text-lg font-semibold">{feature.title}</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

//components/how-it-works
import { Upload, ScanSearch, FileCheck2 } from 'lucide-react'

const steps = [
  { icon: Upload, step: 'Step 01', title: 'Upload Document', description: 'Drag and drop any PDF. Your file is processed securely and never shared.' },
  { icon: ScanSearch, step: 'Step 02', title: 'AI Analysis', description: 'GraphShield scans text, figures, and structure for similarity and manipulation signals.' },
  { icon: FileCheck2, step: 'Step 03', title: 'Review Detailed Report', description: 'Get an explainable risk score with highlighted matches and exportable evidence.' },
]

export function HowItWorks() {
  return (
    <section id="how-it-works" className="scroll-mt-20 border-y border-border/50 bg-card/25 px-6 py-20 md:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-medium text-primary">Process</span>
          <h2 className="mt-3 font-heading text-3xl font-semibold tracking-tight text-balance md:text-4xl">
            How GraphShield works
          </h2>
          <p className="mt-4 text-muted-foreground text-pretty">From upload to verdict in three simple steps.</p>
        </div>

        <div className="relative mt-14 grid gap-6 md:grid-cols-3">
          <div aria-hidden="true"
            className="pointer-events-none absolute left-0 right-0 top-11 hidden h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent md:block" />
          {steps.map((step) => (
            <div key={step.step} className="relative rounded-2xl border border-border/70 bg-background/60 p-7 backdrop-blur-sm">
              <div className="relative z-10 grid size-12 place-items-center rounded-full border border-primary/30 bg-background text-primary shadow-[0_0_24px_-10px_var(--color-primary)]">
                <step.icon className="size-5" />
              </div>
              <p className="mt-5 font-mono text-xs tracking-widest text-primary/80">{step.step}</p>
              <h3 className="mt-2 font-heading text-xl font-semibold">{step.title}</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

//components/cta
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function CallToAction() {
  return (
    <section id="cta" className="scroll-mt-20 px-6 py-20 md:py-28">
      <div className="relative mx-auto max-w-5xl overflow-hidden rounded-3xl border border-border/70 bg-card/60 px-8 py-16 text-center backdrop-blur-xl md:px-16 md:py-20">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute left-1/2 top-0 h-72 w-[560px] -translate-x-1/2 rounded-full bg-primary/20 blur-[120px]" />
        </div>
        <h2 className="mx-auto max-w-2xl font-heading text-3xl font-semibold tracking-tight text-balance md:text-4xl">
          Ready to verify the integrity of your document?
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-muted-foreground text-pretty">
          Run a complete forensic analysis in minutes. Detect plagiarism, visual duplication, and suspicious content before it becomes a problem.
        </p>
        <div className="mt-9 flex justify-center">
          <Button className="h-12 gap-2 px-7 text-sm shadow-[0_0_36px_-8px_var(--color-primary)]">
            Start Analysis <ArrowRight className="size-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}

//components/site-footer
import { Logo } from '@/components/logo'

const groups = [
  { heading: 'Product', links: ['Features', 'How It Works', 'Security', 'Pricing'] },
  { heading: 'Company', links: ['About', 'Careers', 'Contact', 'Blog'] },
  { heading: 'Legal', links: ['Privacy', 'Terms', 'Compliance'] },
]

export function SiteFooter() {
  return (
    <footer id="about" className="scroll-mt-20 border-t border-border/60 px-6 py-14">
      <div className="mx-auto max-w-6xl">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div className="max-w-xs">
            <Logo />
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
              Intelligent document forensics for researchers, publishers, and institutions that value original work.
            </p>
          </div>
          {groups.map((group) => (
            <div key={group.heading}>
              <h3 className="text-sm font-semibold">{group.heading}</h3>
              <ul className="mt-4 space-y-3">
                {group.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-muted-foreground transition-colors hover:text-foreground">{link}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border/60 pt-6 sm:flex-row">
          <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} GraphShield. All rights reserved.</p>
          <p className="text-xs text-muted-foreground">Built for document integrity.</p>
        </div>
      </div>
    </footer>
  )
}