//app dashboard page

import type { Metadata } from 'next'
import { DashboardShell } from '@/components/dashboard/dashboard-shell'
import { WelcomeCard } from '@/components/dashboard/welcome-card'
import { StatCards } from '@/components/dashboard/stat-cards'
import { RecentAnalysis } from '@/components/dashboard/recent-analysis'
import { RiskOverview } from '@/components/dashboard/risk-overview'
import { ActivityChart } from '@/components/dashboard/activity-chart'
import { QuickActions } from '@/components/dashboard/quick-actions'

export const metadata: Metadata = {
  title: 'Dashboard — GraphShield',
  description: 'Overview of your document analysis activity on GraphShield.',
}

export default function DashboardPage() {
  return (
    <DashboardShell>
      <div className="flex flex-col gap-6">
        <WelcomeCard />
        <StatCards />

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <RecentAnalysis />
          </div>
          <div className="lg:col-span-1">
            <RiskOverview />
          </div>
        </div>

        <ActivityChart />
        <QuickActions />
      </div>
    </DashboardShell>
  )
}

//components dashboard activity chart
const data = [
  { day: 'Mon', value: 8 },
  { day: 'Tue', value: 14 },
  { day: 'Wed', value: 11 },
  { day: 'Thu', value: 22 },
  { day: 'Fri', value: 18 },
  { day: 'Sat', value: 27 },
  { day: 'Sun', value: 21 },
]

const width = 640
const height = 220
const padX = 32
const padY = 24

export function ActivityChart() {
  const max = Math.max(...data.map((d) => d.value))
  const stepX = (width - padX * 2) / (data.length - 1)
  const scaleY = (v: number) => height - padY - (v / max) * (height - padY * 2)

  const points = data.map((d, i) => ({
    x: padX + i * stepX,
    y: scaleY(d.value),
    ...d,
  }))

  const line = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ')
  const area = `${line} L ${points[points.length - 1].x} ${height - padY} L ${points[0].x} ${
    height - padY
  } Z`

  const total = data.reduce((sum, d) => sum + d.value, 0)

  return (
    <section className="rounded-2xl border border-border/70 bg-card/50 p-6 backdrop-blur-sm">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-heading text-lg font-semibold">Analysis Activity</h3>
          <p className="text-sm text-muted-foreground">Documents analyzed over the last 7 days</p>
        </div>
        <div className="text-right">
          <p className="font-heading text-2xl font-semibold tracking-tight">{total}</p>
          <p className="text-xs text-muted-foreground">total this week</p>
        </div>
      </div>

      <div className="mt-6 w-full">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="h-56 w-full"
          role="img"
          aria-label="Line chart of documents analyzed over the last 7 days"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="gs-activity-fill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--color-primary)" stopOpacity="0.28" />
              <stop offset="100%" stopColor="var(--color-primary)" stopOpacity="0" />
            </linearGradient>
          </defs>

          {[0.25, 0.5, 0.75, 1].map((t) => (
            <line
              key={t}
              x1={padX}
              x2={width - padX}
              y1={padY + t * (height - padY * 2)}
              y2={padY + t * (height - padY * 2)}
              stroke="var(--color-border)"
              strokeDasharray="4 6"
            />
          ))}

          <path d={area} fill="url(#gs-activity-fill)" />
          <path
            d={line}
            fill="none"
            stroke="var(--color-primary)"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {points.map((p) => (
            <g key={p.day}>
              <circle cx={p.x} cy={p.y} r="4" fill="var(--color-background)" stroke="var(--color-primary)" strokeWidth="2.5" />
              <text
                x={p.x}
                y={height - 4}
                textAnchor="middle"
                className="fill-muted-foreground"
                fontSize="11"
              >
                {p.day}
              </text>
            </g>
          ))}
        </svg>
      </div>
    </section>
  )
}

//components dashboard dashboard shell
'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  LayoutDashboard,
  ScanLine,
  History,
  FileText,
  Settings,
  HelpCircle,
  Bell,
  PanelLeftClose,
  PanelLeftOpen,
  Menu,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Logo } from '@/components/logo'

const navItems = [
  { label: 'Dashboard', icon: LayoutDashboard, href: '/dashboard', active: true },
  { label: 'New Scan', icon: ScanLine, href: '#new-scan' },
  { label: 'Scan History', icon: History, href: '#history' },
  { label: 'Reports', icon: FileText, href: '#reports' },
]

const bottomItems = [
  { label: 'Settings', icon: Settings, href: '#settings' },
  { label: 'Help & Support', icon: HelpCircle, href: '#help' },
]

function ShieldMark() {
  return (
    <span className="relative grid size-9 shrink-0 place-items-center rounded-lg border border-primary/30 bg-primary/10 shadow-[0_0_20px_-6px_var(--color-primary)]">
      <svg viewBox="0 0 24 24" fill="none" className="size-5 text-primary" aria-hidden="true">
        <path
          d="M12 2.5 4 5.5v5.2c0 4.7 3.2 8.4 8 10.8 4.8-2.4 8-6.1 8-10.8V5.5l-8-3Z"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
        <circle cx="9.2" cy="10" r="1.4" fill="currentColor" />
        <circle cx="15" cy="8.4" r="1.2" fill="currentColor" />
        <circle cx="14.4" cy="14" r="1.3" fill="currentColor" />
        <path
          d="M9.2 10 15 8.4M9.2 10l5.2 4M15 8.4l-.6 5.6"
          stroke="currentColor"
          strokeWidth="1.1"
          strokeLinecap="round"
        />
      </svg>
    </span>
  )
}

function NavList({
  collapsed,
  onNavigate,
}: {
  collapsed: boolean
  onNavigate?: () => void
}) {
  return (
    <nav className="flex flex-1 flex-col gap-1 px-3">
      <p
        className={cn(
          'px-3 pt-2 pb-1 text-[0.65rem] font-medium uppercase tracking-widest text-muted-foreground/70',
          collapsed && 'sr-only',
        )}
      >
        Menu
      </p>
      {navItems.map((item) => (
        <Link
          key={item.label}
          href={item.href}
          onClick={onNavigate}
          aria-current={item.active ? 'page' : undefined}
          title={collapsed ? item.label : undefined}
          className={cn(
            'group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors',
            collapsed && 'justify-center px-0',
            item.active
              ? 'bg-primary/12 text-primary shadow-[inset_0_0_0_1px_var(--color-primary)]/20'
              : 'text-muted-foreground hover:bg-sidebar-accent hover:text-foreground',
          )}
        >
          <item.icon className="size-[18px] shrink-0" />
          {!collapsed && <span>{item.label}</span>}
        </Link>
      ))}
    </nav>
  )
}

function SidebarContent({
  collapsed,
  onNavigate,
}: {
  collapsed: boolean
  onNavigate?: () => void
}) {
  return (
    <div className="flex h-full flex-col">
      <div className={cn('flex h-16 items-center px-5', collapsed && 'justify-center px-0')}>
        {collapsed ? (
          <ShieldMark />
        ) : (
          <Link href="/dashboard" aria-label="GraphShield dashboard">
            <Logo />
          </Link>
        )}
      </div>

      <div className="mt-2 flex-1">
        <NavList collapsed={collapsed} onNavigate={onNavigate} />
      </div>

      <div className="mt-auto border-t border-sidebar-border px-3 py-3">
        {bottomItems.map((item) => (
          <Link
            key={item.label}
            href={item.href}
            onClick={onNavigate}
            title={collapsed ? item.label : undefined}
            className={cn(
              'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground',
              collapsed && 'justify-center px-0',
            )}
          >
            <item.icon className="size-[18px] shrink-0" />
            {!collapsed && <span>{item.label}</span>}
          </Link>
        ))}
      </div>
    </div>
  )
}

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 hidden border-r border-sidebar-border bg-sidebar transition-[width] duration-300 md:block',
          collapsed ? 'w-[76px]' : 'w-64',
        )}
      >
        <SidebarContent collapsed={collapsed} />
      </aside>

      {/* Mobile sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <button
            type="button"
            aria-label="Close menu"
            onClick={() => setMobileOpen(false)}
            className="absolute inset-0 bg-background/70 backdrop-blur-sm"
          />
          <aside className="relative h-full w-64 border-r border-sidebar-border bg-sidebar">
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              aria-label="Close menu"
              className="absolute right-3 top-4 grid size-8 place-items-center rounded-lg text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"
            >
              <X className="size-5" />
            </button>
            <SidebarContent collapsed={false} onNavigate={() => setMobileOpen(false)} />
          </aside>
        </div>
      )}

      <div className={cn('transition-[padding] duration-300', collapsed ? 'md:pl-[76px]' : 'md:pl-64')}>
        {/* Top header */}
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border/60 bg-background/70 px-4 backdrop-blur-xl md:px-8">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
            className="grid size-9 place-items-center rounded-lg border border-border text-foreground md:hidden"
          >
            <Menu className="size-5" />
          </button>

          <button
            type="button"
            onClick={() => setCollapsed((v) => !v)}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="hidden size-9 place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground md:grid"
          >
            {collapsed ? <PanelLeftOpen className="size-5" /> : <PanelLeftClose className="size-5" />}
          </button>

          <div className="min-w-0 flex-1">
            <h1 className="font-heading text-base font-semibold leading-tight tracking-tight sm:text-lg">
              Dashboard
            </h1>
            <p className="truncate text-xs text-muted-foreground">
              Overview of your document analysis activity
            </p>
          </div>

          <button
            type="button"
            aria-label="Notifications"
            className="relative grid size-9 place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <Bell className="size-5" />
            <span className="absolute right-2 top-2 size-2 rounded-full bg-primary ring-2 ring-background" />
          </button>

          <button
            type="button"
            aria-label="Account menu"
            className="flex items-center gap-2.5 rounded-lg p-1 pr-2.5 transition-colors hover:bg-muted"
          >
            <span className="grid size-8 place-items-center rounded-full bg-primary/15 font-heading text-sm font-semibold text-primary">
              AR
            </span>
            <span className="hidden text-left leading-tight sm:block">
              <span className="block text-sm font-medium">Alex Rivera</span>
              <span className="block text-xs text-muted-foreground">Researcher</span>
            </span>
          </button>
        </header>

        <main className="mx-auto max-w-7xl px-4 py-6 md:px-8 md:py-8">{children}</main>
      </div>
    </div>
  )
}

//compomnent/dashboard/quick action
import Link from 'next/link'
import { ScanLine, History, Download, ArrowUpRight } from 'lucide-react'

const actions = [
  {
    label: 'New Document Scan',
    description: 'Upload and analyze a PDF',
    icon: ScanLine,
    href: '#new-scan',
  },
  {
    label: 'View Scan History',
    description: 'Browse past analyses',
    icon: History,
    href: '#history',
  },
  {
    label: 'Download Reports',
    description: 'Export forensic reports',
    icon: Download,
    href: '#reports',
  },
]

export function QuickActions() {
  return (
    <section>
      <h3 className="mb-4 font-heading text-lg font-semibold">Quick Actions</h3>
      <div className="grid gap-4 sm:grid-cols-3">
        {actions.map((action) => (
          <Link
            key={action.label}
            href={action.href}
            className="group flex items-center gap-4 rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:bg-card/80"
          >
            <span className="grid size-11 shrink-0 place-items-center rounded-xl border border-primary/25 bg-primary/10 text-primary transition-colors group-hover:bg-primary/15">
              <action.icon className="size-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-medium">{action.label}</p>
              <p className="text-sm text-muted-foreground">{action.description}</p>
            </div>
            <ArrowUpRight className="size-4 shrink-0 text-muted-foreground transition-colors group-hover:text-primary" />
          </Link>
        ))}
      </div>
    </section>
  )
}
//components/dashboard/recent-analysis
import Link from 'next/link'
import { FileText, ArrowRight, Eye } from 'lucide-react'
import { cn } from '@/lib/utils'

type Status = 'Low Risk' | 'Medium Risk' | 'High Risk'

type Row = {
  name: string
  date: string
  textRisk: number
  visualRisk: number
  status: Status
}

const rows: Row[] = [
  { name: 'Thesis_Chapter_04.pdf', date: 'Sep 4, 2026', textRisk: 12, visualRisk: 8, status: 'Low Risk' },
  { name: 'Research_Paper_v2.pdf', date: 'Sep 3, 2026', textRisk: 41, visualRisk: 33, status: 'Medium Risk' },
  { name: 'Grant_Proposal_Final.pdf', date: 'Sep 2, 2026', textRisk: 74, visualRisk: 68, status: 'High Risk' },
  { name: 'Conference_Abstract.pdf', date: 'Aug 30, 2026', textRisk: 19, visualRisk: 22, status: 'Low Risk' },
  { name: 'Literature_Review.pdf', date: 'Aug 28, 2026', textRisk: 38, visualRisk: 44, status: 'Medium Risk' },
]

const statusStyles: Record<Status, string> = {
  'Low Risk': 'border-primary/30 bg-primary/10 text-primary',
  'Medium Risk': 'border-amber-400/25 bg-amber-400/10 text-amber-300',
  'High Risk': 'border-destructive/30 bg-destructive/10 text-destructive',
}

function RiskMeter({ value }: { value: number }) {
  const tone =
    value >= 60 ? 'bg-destructive' : value >= 30 ? 'bg-amber-400' : 'bg-primary'
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-16 overflow-hidden rounded-full bg-muted">
        <div className={cn('h-full rounded-full', tone)} style={{ width: `${value}%` }} />
      </div>
      <span className="w-9 text-xs tabular-nums text-muted-foreground">{value}%</span>
    </div>
  )
}

export function RecentAnalysis() {
  return (
    <section className="rounded-2xl border border-border/70 bg-card/50 backdrop-blur-sm">
      <div className="flex items-center justify-between gap-4 border-b border-border/60 px-5 py-4 md:px-6">
        <div>
          <h3 className="font-heading text-lg font-semibold">Recent Analysis</h3>
          <p className="text-sm text-muted-foreground">Your latest document scans</p>
        </div>
        <Link
          href="#history"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-primary transition-colors hover:text-primary/80"
        >
          View All History
          <ArrowRight className="size-4" />
        </Link>
      </div>

      {/* Desktop table */}
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-border/60 text-xs uppercase tracking-wider text-muted-foreground/70">
              <th className="px-6 py-3 font-medium">Document</th>
              <th className="px-6 py-3 font-medium">Date</th>
              <th className="px-6 py-3 font-medium">Text Risk</th>
              <th className="px-6 py-3 font-medium">Visual Risk</th>
              <th className="px-6 py-3 font-medium">Status</th>
              <th className="px-6 py-3 text-right font-medium">Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr
                key={row.name}
                className="border-b border-border/40 transition-colors last:border-0 hover:bg-muted/40"
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <span className="grid size-9 shrink-0 place-items-center rounded-lg border border-border bg-muted/40 text-muted-foreground">
                      <FileText className="size-4" />
                    </span>
                    <span className="font-medium">{row.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-muted-foreground">{row.date}</td>
                <td className="px-6 py-4">
                  <RiskMeter value={row.textRisk} />
                </td>
                <td className="px-6 py-4">
                  <RiskMeter value={row.visualRisk} />
                </td>
                <td className="px-6 py-4">
                  <span
                    className={cn(
                      'inline-flex rounded-full border px-2.5 py-0.5 text-xs font-medium',
                      statusStyles[row.status],
                    )}
                  >
                    {row.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <Link
                    href="#reports"
                    aria-label={`View report for ${row.name}`}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
                  >
                    <Eye className="size-3.5" />
                    View
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <ul className="divide-y divide-border/40 md:hidden">
        {rows.map((row) => (
          <li key={row.name} className="px-5 py-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex min-w-0 items-center gap-3">
                <span className="grid size-9 shrink-0 place-items-center rounded-lg border border-border bg-muted/40 text-muted-foreground">
                  <FileText className="size-4" />
                </span>
                <div className="min-w-0">
                  <p className="truncate font-medium">{row.name}</p>
                  <p className="text-xs text-muted-foreground">{row.date}</p>
                </div>
              </div>
              <span
                className={cn(
                  'shrink-0 rounded-full border px-2.5 py-0.5 text-xs font-medium',
                  statusStyles[row.status],
                )}
              >
                {row.status}
              </span>
            </div>
            <div className="mt-3 flex items-center gap-6">
              <div>
                <p className="mb-1 text-xs text-muted-foreground">Text</p>
                <RiskMeter value={row.textRisk} />
              </div>
              <div>
                <p className="mb-1 text-xs text-muted-foreground">Visual</p>
                <RiskMeter value={row.visualRisk} />
              </div>
            </div>
          </li>
        ))}
      </ul>
    </section>
  )
}

//components/dashboard/risk-overview
const metrics = [
  { label: 'Text Similarity Risk', value: 18 },
  { label: 'Visual Similarity Risk', value: 31 },
]

const overall = 24

function Gauge({ value }: { value: number }) {
  const radius = 52
  const circumference = 2 * Math.PI * radius
  const dash = (value / 100) * circumference

  return (
    <div className="relative grid size-40 place-items-center">
      <svg viewBox="0 0 130 130" className="size-40 -rotate-90">
        <circle
          cx="65"
          cy="65"
          r={radius}
          fill="none"
          stroke="var(--color-muted)"
          strokeWidth="10"
        />
        <circle
          cx="65"
          cy="65"
          r={radius}
          fill="none"
          stroke="var(--color-primary)"
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circumference}`}
          className="transition-[stroke-dasharray] duration-700 ease-out"
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="font-heading text-3xl font-semibold tracking-tight">{value}%</span>
        <span className="text-xs text-muted-foreground">Overall Risk</span>
      </div>
    </div>
  )
}

function LinearMetric({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium tabular-nums">{value}%</span>
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-primary transition-[width] duration-700 ease-out"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  )
}

export function RiskOverview() {
  return (
    <section className="rounded-2xl border border-border/70 bg-card/50 p-6 backdrop-blur-sm">
      <h3 className="font-heading text-lg font-semibold">Risk Overview</h3>
      <p className="text-sm text-muted-foreground">Aggregated across recent documents</p>

      <div className="mt-4 flex justify-center">
        <Gauge value={overall} />
      </div>

      <div className="mt-4 space-y-4">
        {metrics.map((m) => (
          <LinearMetric key={m.label} label={m.label} value={m.value} />
        ))}
      </div>
    </section>
  )
}

//components/dashboard/stat-cards
import { FileStack, Gauge, ShieldAlert, FileCheck2, TrendingUp, TrendingDown } from 'lucide-react'

const stats = [
  {
    label: 'Documents Analyzed',
    value: '128',
    icon: FileStack,
    trend: '+12%',
    up: true,
    note: 'vs last month',
  },
  {
    label: 'Average Risk Score',
    value: '24%',
    icon: Gauge,
    trend: '-3%',
    up: false,
    note: 'vs last month',
  },
  {
    label: 'Potential Issues Found',
    value: '37',
    icon: ShieldAlert,
    trend: '+5',
    up: true,
    note: 'this month',
  },
  {
    label: 'Reports Generated',
    value: '96',
    icon: FileCheck2,
    trend: '+18%',
    up: true,
    note: 'vs last month',
  },
]

export function StatCards() {
  return (
    <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="group rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:bg-card/80"
        >
          <div className="flex items-center justify-between">
            <span className="grid size-10 place-items-center rounded-xl border border-primary/25 bg-primary/10 text-primary">
              <stat.icon className="size-5" />
            </span>
            <span
              className={`flex items-center gap-1 text-xs font-medium ${
                stat.up ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              {stat.up ? <TrendingUp className="size-3.5" /> : <TrendingDown className="size-3.5" />}
              {stat.trend}
            </span>
          </div>
          <p className="mt-4 font-heading text-3xl font-semibold tracking-tight">{stat.value}</p>
          <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
          <p className="mt-0.5 text-xs text-muted-foreground/70">{stat.note}</p>
        </div>
      ))}
    </section>
  )
}

//components/dashboard/welc-card
import Link from 'next/link'
import { Plus, FileSearch } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function WelcomeCard() {
  return (
    <section className="animate-fade-up relative overflow-hidden rounded-2xl border border-border/70 bg-card/60 p-6 backdrop-blur-sm md:p-8">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-16 -top-16 size-64 rounded-full bg-primary/10 blur-[90px]"
      />
      <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div className="max-w-xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <FileSearch className="size-3.5" />
            GraphShield Analysis
          </span>
          <h2 className="mt-4 font-heading text-2xl font-semibold tracking-tight text-balance md:text-3xl">
            Ready to analyze your next document?
          </h2>
          <p className="mt-3 leading-relaxed text-muted-foreground text-pretty">
            Upload a document and let GraphShield analyze text similarity, visual duplication and
            potential content risks.
          </p>
        </div>
        <div className="shrink-0">
          <Button
            nativeButton={false}
            render={<Link href="#new-scan" />}
            className="h-12 gap-2 px-6 text-sm shadow-[0_0_30px_-8px_var(--color-primary)]"
          >
            <Plus className="size-4" />
            New Analysis
          </Button>
        </div>
      </div>
    </section>
  )
}