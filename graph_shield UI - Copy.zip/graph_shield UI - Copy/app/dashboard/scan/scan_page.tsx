'use client'

import { useState, useRef, type DragEvent, type ChangeEvent } from 'react'
import Link from 'next/link'
import {
  Upload,
  FileText,
  X,
  CheckCircle2,
  Sparkles,
  FileSearch,
  Images,
  ShieldAlert,
  ArrowRight,
  Loader2,
  Eye,
  AlertCircle,
  FileCheck,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { DashboardShell } from '@/components/dashboard/dashboard-shell'
import { Button } from '@/components/ui/button'

type FileState = {
  file: File
  name: string
  size: string
} | null

type RecentScan = {
  name: string
  date: string
  riskLevel: 'Low Risk' | 'Medium Risk' | 'High Risk'
}

const recentScans: RecentScan[] = [
  { name: 'Thesis_Chapter_04.pdf', date: 'Sep 4, 2026', riskLevel: 'Low Risk' },
  { name: 'Research_Paper_v2.pdf', date: 'Sep 3, 2026', riskLevel: 'Medium Risk' },
  { name: 'Grant_Proposal_Final.pdf', date: 'Sep 2, 2026', riskLevel: 'High Risk' },
]

const riskStyles: Record<RecentScan['riskLevel'], string> = {
  'Low Risk': 'border-primary/30 bg-primary/10 text-primary',
  'Medium Risk': 'border-amber-400/25 bg-amber-400/10 text-amber-300',
  'High Risk': 'border-destructive/30 bg-destructive/10 text-destructive',
}

export default function NewScanPage() {
  const [fileData, setFileData] = useState<FileState>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  // Options State
  const [options, setOptions] = useState({
    textAnalysis: true,
    visualAnalysis: true,
    comprehensive: true,
  })

  const fileInputRef = useRef<HTMLInputElement>(null)

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`
  }

  const validateAndSetFile = (file: File) => {
    setError(null)
    if (file.type !== 'application/pdf' && !file.name.endsWith('.pdf')) {
      setError('Invalid file type. Please upload a valid PDF document.')
      return
    }
    setFileData({
      file,
      name: file.name,
      size: formatFileSize(file.size),
    })
  }

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(true)
  }

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndSetFile(e.dataTransfer.files[0])
    }
  }

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndSetFile(e.target.files[0])
    }
  }

  const handleRemoveFile = () => {
    setFileData(null)
    setError(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const handleStartAnalysis = () => {
    if (!fileData) return
    setIsAnalyzing(true)
    // Simulate navigation or scanning complete after 2 seconds
    setTimeout(() => {
      setIsAnalyzing(false)
      alert(`Simulation complete! Analyzed: ${fileData.name}`)
    }, 2000)
  }

  const toggleOption = (key: keyof typeof options) => {
    setOptions((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <DashboardShell>
      <div className="mx-auto max-w-5xl space-y-10">
        {/* 1. Page Header */}
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/25 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              <Sparkles className="size-3.5" />
              Document Forensics
            </span>
          </div>
          <h1 className="mt-3 font-heading text-2xl font-semibold tracking-tight md:text-3xl">
            New Document Analysis
          </h1>
          <p className="mt-1 text-sm text-muted-foreground md:text-base">
            Upload a document to analyze text similarity, visual duplication and potential content risks.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Left Column: Upload Workflow & Configuration */}
          <div className="space-y-8 lg:col-span-2">
            {/* 2 & 3. Main Upload Area or Selected File Preview */}
            <div className="space-y-3">
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,application/pdf"
                className="hidden"
                onChange={handleFileChange}
              />

              {!fileData ? (
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={cn(
                    'group relative flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-8 text-center transition-all duration-300 backdrop-blur-sm md:p-12',
                    isDragging
                      ? 'border-primary bg-primary/10 shadow-[0_0_30px_-5px_var(--color-primary)]'
                      : 'border-border/80 bg-card/40 hover:border-primary/50 hover:bg-card/70 hover:shadow-[0_0_20px_-8px_var(--color-primary)]',
                  )}
                >
                  <div className="grid size-16 place-items-center rounded-2xl border border-primary/25 bg-primary/10 text-primary transition-transform duration-300 group-hover:scale-110">
                    <Upload className="size-7" />
                  </div>

                  <h3 className="mt-5 font-heading text-lg font-semibold">
                    Drag and drop your document here
                  </h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    or click to browse files from your computer
                  </p>

                  <div className="mt-6">
                    <Button
                      type="button"
                      variant="outline"
                      className="pointer-events-none h-10 border-primary/30 px-5 text-sm font-medium text-foreground group-hover:border-primary group-hover:bg-primary/10"
                    >
                      Browse File
                    </Button>
                  </div>

                  <span className="mt-4 text-xs text-muted-foreground/70">
                    Supports PDF format up to 50 MB
                  </span>
                </div>
              ) : (
                /* Selected File Preview */
                <div className="relative overflow-hidden rounded-2xl border border-primary/30 bg-card/80 p-6 backdrop-blur-sm shadow-[0_0_25px_-10px_var(--color-primary)]">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="grid size-12 shrink-0 place-items-center rounded-xl border border-primary/30 bg-primary/15 text-primary">
                        <FileText className="size-6" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="truncate font-heading font-medium text-foreground">
                            {fileData.name}
                          </p>
                          <span className="inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">
                            <CheckCircle2 className="size-3" /> Ready
                          </span>
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">
                          PDF Document • {fileData.size}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleRemoveFile}
                      aria-label="Remove document"
                      className="grid size-8 place-items-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                    >
                      <X className="size-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* Friendly Error Message */}
              {error && (
                <div className="flex items-center gap-2 rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
                  <AlertCircle className="size-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}
            </div>

            {/* 4. Analysis Options */}
            <div className="rounded-2xl border border-border/70 bg-card/50 p-6 backdrop-blur-sm space-y-5">
              <h3 className="font-heading text-lg font-semibold">Analysis Configuration</h3>

              <div className="space-y-3">
                {/* Text Analysis Toggle */}
                <div
                  onClick={() => toggleOption('textAnalysis')}
                  className="flex cursor-pointer items-start justify-between gap-4 rounded-xl border border-border/50 bg-background/40 p-4 transition-colors hover:border-border hover:bg-background/60"
                >
                  <div>
                    <p className="text-sm font-medium">Text Analysis</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Detect potentially similar, plagiarized or suspicious textual content.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={options.textAnalysis}
                    onChange={() => {}}
                    className="size-4 rounded border-border accent-primary"
                  />
                </div>

                {/* Visual Analysis Toggle */}
                <div
                  onClick={() => toggleOption('visualAnalysis')}
                  className="flex cursor-pointer items-start justify-between gap-4 rounded-xl border border-border/50 bg-background/40 p-4 transition-colors hover:border-border hover:bg-background/60"
                >
                  <div>
                    <p className="text-sm font-medium">Visual &amp; Figure Analysis</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Analyze images, figures and visual structures for duplication or manipulation.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={options.visualAnalysis}
                    onChange={() => {}}
                    className="size-4 rounded border-border accent-primary"
                  />
                </div>

                {/* Comprehensive Mode Toggle */}
                <div
                  onClick={() => toggleOption('comprehensive')}
                  className="flex cursor-pointer items-start justify-between gap-4 rounded-xl border border-border/50 bg-background/40 p-4 transition-colors hover:border-border hover:bg-background/60"
                >
                  <div>
                    <p className="text-sm font-medium">Comprehensive Check</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Run all available GraphShield forensic heuristics and deep semantic checks.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={options.comprehensive}
                    onChange={() => {}}
                    className="size-4 rounded border-border accent-primary"
                  />
                </div>
              </div>
            </div>

            {/* 5. Start Analysis CTA */}
            <div>
              <Button
                disabled={!fileData || isAnalyzing}
                onClick={handleStartAnalysis}
                className="h-12 w-full gap-2 text-sm shadow-[0_0_30px_-8px_var(--color-primary)] disabled:opacity-50 disabled:shadow-none"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="size-4 animate-spin" />
                    Analyzing Document...
                  </>
                ) : (
                  <>
                    <FileCheck className="size-4" />
                    Start Analysis
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Right Column: Informative Cards & Compact Recent Uploads */}
          <div className="space-y-8">
            {/* 6. What GraphShield Will Analyze */}
            <div className="space-y-4">
              <h3 className="font-heading text-base font-semibold">What GraphShield Analyzes</h3>

              <div className="space-y-3">
                <div className="group rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:bg-card/80">
                  <div className="grid size-10 place-items-center rounded-xl border border-primary/25 bg-primary/10 text-primary">
                    <FileSearch className="size-5" />
                  </div>
                  <h4 className="mt-3 font-heading font-medium">Text Similarity</h4>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    Analyzes document text for potentially duplicated, paraphrased or suspicious content.
                  </p>
                </div>

                <div className="group rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:bg-card/80">
                  <div className="grid size-10 place-items-center rounded-xl border border-primary/25 bg-primary/10 text-primary">
                    <Images className="size-5" />
                  </div>
                  <h4 className="mt-3 font-heading font-medium">Visual Similarity</h4>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    Scans figures, diagrams and images embedded within the file for reuse.
                  </p>
                </div>

                <div className="group rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40 hover:bg-card/80">
                  <div className="grid size-10 place-items-center rounded-xl border border-primary/25 bg-primary/10 text-primary">
                    <ShieldAlert className="size-5" />
                  </div>
                  <h4 className="mt-3 font-heading font-medium">Risk Assessment</h4>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    Generates an overall, explainable score combining all detected metrics.
                  </p>
                </div>
              </div>
            </div>

            {/* 7. Recent Uploads (Compact Secondary Section) */}
            <div className="rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-heading text-sm font-semibold text-muted-foreground">
                  Recent Uploads
                </h3>
                <Link
                  href="#history"
                  className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                >
                  View all <ArrowRight className="size-3" />
                </Link>
              </div>

              <div className="divide-y divide-border/40">
                {recentScans.map((scan) => (
                  <div key={scan.name} className="flex items-center justify-between py-3 first:pt-0 last:pb-0">
                    <div className="min-w-0 pr-2">
                      <p className="truncate text-xs font-medium">{scan.name}</p>
                      <p className="text-[10px] text-muted-foreground">{scan.date}</p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={cn(
                          'rounded-full border px-2 py-0.5 text-[10px] font-medium',
                          riskStyles[scan.riskLevel],
                        )}
                      >
                        {scan.riskLevel}
                      </span>
                      <Link
                        href="#reports"
                        aria-label={`View ${scan.name}`}
                        className="grid size-7 place-items-center rounded-lg border border-border text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
                      >
                        <Eye className="size-3.5" />
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardShell>
  )
}