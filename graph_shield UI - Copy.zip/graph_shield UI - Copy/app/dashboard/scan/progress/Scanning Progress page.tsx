'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import {
  FileText,
  CheckCircle2,
  Loader2,
  Circle,
  Sparkles,
  ShieldCheck,
  FileSearch,
  Images,
  Cpu,
  FileSpreadsheet,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { DashboardShell } from '@/components/dashboard/dashboard-shell'

type StageState = 'completed' | 'processing' | 'waiting'

interface Stage {
  id: string
  label: string
  description: string
  state: StageState
}

const INITIAL_STAGES: Stage[] = [
  {
    id: 'upload',
    label: 'Uploading Document',
    description: 'Securely receiving and validating file format',
    state: 'processing',
  },
  {
    id: 'text-extract',
    label: 'Extracting Text Content',
    description: 'Parsing document structure and typography',
    state: 'waiting',
  },
  {
    id: 'image-extract',
    label: 'Extracting Images and Figures',
    description: 'Isolating embedded diagrams, plots, and figures',
    state: 'waiting',
  },
  {
    id: 'text-sim',
    label: 'Analyzing Text Similarity',
    description: 'Performing semantic search across global databases',
    state: 'waiting',
  },
  {
    id: 'visual-sim',
    label: 'Analyzing Visual Similarity',
    description: 'Running visual fingerprinting on figures and diagrams',
    state: 'waiting',
  },
  {
    id: 'risk-score',
    label: 'Calculating Risk Scores',
    description: 'Weighting heuristic signals and overall confidence',
    state: 'waiting',
  },
  {
    id: 'report-gen',
    label: 'Generating Audit Report',
    description: 'Compiling interactive evidence and report artifacts',
    state: 'waiting',
  },
]

export default function ScanningProgressPage() {
  const router = useRouter()

  // Mock File Info (In production, retrieve via state management or router query/params)
  const fileInfo = {
    name: 'Research_Paper_v2_Final.pdf',
    size: '2.4 MB',
    type: 'PDF Document',
  }

  const [progress, setProgress] = useState(0)
  const [stages, setStages] = useState<Stage[]>(INITIAL_STAGES)

  useEffect(() => {
    // Stage step progression simulation over 7 seconds total
    const interval = setInterval(() => {
      setProgress((prevProgress) => {
        const nextProgress = prevProgress + 1

        // Update stages state dynamically based on overall percentage completion
        const updatedStages = INITIAL_STAGES.map((stage, index) => {
          const stepThreshold = Math.floor(((index + 1) / INITIAL_STAGES.length) * 100)
          const startThreshold = Math.floor((index / INITIAL_STAGES.length) * 100)

          if (nextProgress >= stepThreshold) {
            return { ...stage, state: 'completed' as StageState }
          } else if (nextProgress >= startThreshold) {
            return { ...stage, state: 'processing' as StageState }
          } else {
            return { ...stage, state: 'waiting' as StageState }
          }
        })

        setStages(updatedStages)

        // Automatically navigate to results page upon reaching 100%
        if (nextProgress >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            router.push('/dashboard/scan/results') // Future Results Page Route
          }, 600)
        }

        return nextProgress
      })
    }, 70) // ~7 sec total run time

    return () => clearInterval(interval)
  }, [router])

  return (
    <DashboardShell>
      <div className="mx-auto max-w-4xl space-y-8">
        {/* Header */}
        <div className="text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/25 bg-primary/10 px-3.5 py-1 text-xs font-medium text-primary">
            <Sparkles className="size-3.5" />
            Active Scan
          </span>
          <h1 className="mt-4 font-heading text-2xl font-semibold tracking-tight sm:text-3xl md:text-4xl">
            Analyzing Your Document
          </h1>
          <p className="mt-2 text-sm text-muted-foreground md:text-base">
            GraphShield is performing a comprehensive analysis of your document.
          </p>
        </div>

        {/* Document Information Card */}
        <div className="relative overflow-hidden rounded-2xl border border-border/70 bg-card/60 p-5 backdrop-blur-sm md:p-6">
          <div className="flex items-center gap-4">
            <div className="grid size-12 shrink-0 place-items-center rounded-xl border border-primary/30 bg-primary/15 text-primary">
              <FileText className="size-6" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate font-heading font-medium text-foreground text-base">
                {fileInfo.name}
              </p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {fileInfo.type} • {fileInfo.size}
              </p>
            </div>
            <div className="hidden items-center gap-2 text-xs text-muted-foreground sm:flex">
              <ShieldCheck className="size-4 text-primary" />
              End-to-end encrypted
            </div>
          </div>
        </div>

        {/* Analysis Progress Gauge / Bar */}
        <div className="rounded-2xl border border-border/70 bg-card/50 p-6 backdrop-blur-sm md:p-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Loader2 className="size-4 animate-spin text-primary" />
              <p className="font-heading font-medium text-foreground text-sm sm:text-base">
                Analyzing Document...
              </p>
            </div>
            <span className="font-heading text-xl font-semibold tabular-nums text-primary md:text-2xl">
              {progress}%
            </span>
          </div>

          <div className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full bg-primary shadow-[0_0_15px_-2px_var(--color-primary)] transition-[width] duration-200 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Analysis Stages Vertical Timeline */}
        <div className="rounded-2xl border border-border/70 bg-card/50 p-6 backdrop-blur-sm md:p-8">
          <h3 className="font-heading text-lg font-semibold">Analysis Stages</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Progress updates automatically in real-time as each phase completes.
          </p>

          <div className="relative mt-8 space-y-6 before:absolute before:left-[17px] before:top-3 before:h-[calc(100%-24px)] before:w-0.5 before:bg-border/60">
            {stages.map((stage) => (
              <div key={stage.id} className="relative flex items-start gap-4">
                {/* Stage Status Icon */}
                <div className="relative z-10 grid size-9 shrink-0 place-items-center rounded-full bg-background">
                  {stage.state === 'completed' && (
                    <CheckCircle2 className="size-6 text-primary" />
                  )}
                  {stage.state === 'processing' && (
                    <div className="grid size-9 place-items-center rounded-full border border-primary/30 bg-primary/10">
                      <Loader2 className="size-5 animate-spin text-primary" />
                    </div>
                  )}
                  {stage.state === 'waiting' && (
                    <Circle className="size-5 text-muted-foreground/40" />
                  )}
                </div>

                {/* Stage Details */}
                <div className="min-w-0 pt-0.5">
                  <p
                    className={cn(
                      'font-heading text-sm font-medium transition-colors',
                      stage.state === 'completed' && 'text-foreground',
                      stage.state === 'processing' && 'text-primary font-semibold',
                      stage.state === 'waiting' && 'text-muted-foreground/60',
                    )}
                  >
                    {stage.label}
                  </p>
                  <p
                    className={cn(
                      'mt-0.5 text-xs transition-colors',
                      stage.state === 'waiting'
                        ? 'text-muted-foreground/40'
                        : 'text-muted-foreground',
                    )}
                  >
                    {stage.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Informative Grid */}
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-border/60 bg-card/30 p-4 backdrop-blur-sm">
            <FileSearch className="size-5 text-primary" />
            <h4 className="mt-2 font-heading text-xs font-medium">Semantic Search</h4>
            <p className="mt-1 text-[11px] text-muted-foreground">
              Deep comparison against reference archives and indexes.
            </p>
          </div>

          <div className="rounded-xl border border-border/60 bg-card/30 p-4 backdrop-blur-sm">
            <Images className="size-5 text-primary" />
            <h4 className="mt-2 font-heading text-xs font-medium">Figure Hashing</h4>
            <p className="mt-1 text-[11px] text-muted-foreground">
              Detects duplicated, rotated, or cropped charts and images.
            </p>
          </div>

          <div className="rounded-xl border border-border/60 bg-card/30 p-4 backdrop-blur-sm">
            <Cpu className="size-5 text-primary" />
            <h4 className="mt-2 font-heading text-xs font-medium">Explainable Risk</h4>
            <p className="mt-1 text-[11px] text-muted-foreground">
              Generates granular, forensic-backed evidence reports.
            </p>
          </div>
        </div>
      </div>
    </DashboardShell>
  )
}