'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  FileText,
  CheckCircle2,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  Download,
  PlusCircle,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Eye,
  Clock,
  Layers,
  Images,
  FileSearch,
  ExternalLink,
  CheckSquare,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { DashboardShell } from '@/components/dashboard/dashboard-shell'
import { Button } from '@/components/ui/button'

// 10. Conceptual Data Model structured for backend alignment (FastAPI POST /scan-pdf)
export interface FindingItem {
  id: string
  type: 'Visual Similarity' | 'Text Similarity'
  riskLevel: 'Low Risk' | 'Medium Risk' | 'High Risk' | 'Critical Risk'
  similarity: number
  summary: string
  details: string
  source?: string
}

export interface AnalysisResult {
  filename: string
  file_size: string
  figures_analyzed: number
  text_passages_analyzed: number
  image_risk: number
  text_risk: number
  overall_score: number
  overall_status: 'Low Risk' | 'Medium Risk' | 'High Risk' | 'Critical Risk'
  potential_issues_count: number
  analysis_duration: string
  completed_at: string
  report_generated: boolean
  findings: FindingItem[]
}

// Realistic Mock Response
const MOCK_ANALYSIS_DATA: AnalysisResult = {
  filename: 'research_paper_v2_final.pdf',
  file_size: '2.4 MB',
  figures_analyzed: 12,
  text_passages_analyzed: 24,
  image_risk: 47,
  text_risk: 28,
  overall_score: 42,
  overall_status: 'Medium Risk',
  potential_issues_count: 5,
  analysis_duration: '1m 32s',
  completed_at: 'Sep 5, 2026 • 11:45 AM',
  report_generated: true,
  findings: [
    {
      id: 'find-1',
      type: 'Visual Similarity',
      riskLevel: 'High Risk',
      similarity: 87,
      summary: 'Potentially similar figure detected in Figure 3.',
      details:
        'Visual hashing matched Figure 3 against a previously indexed chart in IEEE Database (2024). Spatial orientation, axis scales, and pixel patterns show 87% structural correspondence.',
      source: 'IEEE Transactions on Machine Learning, Vol. 14, Fig. 2',
    },
    {
      id: 'find-2',
      type: 'Text Similarity',
      riskLevel: 'Medium Risk',
      similarity: 64,
      summary: 'Potential textual similarity detected in Section 4.2.',
      details:
        'A sequence of 42 consecutive words in the methodology section matches verbatim with an online published preprint without explicit quotation block tags.',
      source: 'ArXiv Repository: arXiv:2308.0912',
    },
    {
      id: 'find-3',
      type: 'Visual Similarity',
      riskLevel: 'Medium Risk',
      similarity: 52,
      summary: 'Cropped diagram detected in Section 2.',
      details:
        'Diagram 1 contains cropped regions that share color palettes and boundary vector curves with an open-access repository diagram.',
      source: 'BioMed Central Commons, Fig. 1B',
    },
    {
      id: 'find-4',
      type: 'Text Similarity',
      riskLevel: 'Low Risk',
      similarity: 31,
      summary: 'Standardized citation phrasing matches generic patterns.',
      details:
        'Common introductory literature review phrasing found across multiple academic papers. Classified as low forensic concern.',
    },
  ],
}

const statusBadgeStyles: Record<AnalysisResult['overall_status'], string> = {
  'Low Risk': 'border-primary/30 bg-primary/10 text-primary',
  'Medium Risk': 'border-amber-400/30 bg-amber-400/10 text-amber-300',
  'High Risk': 'border-destructive/30 bg-destructive/10 text-destructive',
  'Critical Risk': 'border-red-600/40 bg-red-600/20 text-red-400',
}

function RiskGauge({ score }: { score: number }) {
  const radius = 54
  const circumference = 2 * Math.PI * radius
  const dash = (score / 100) * circumference

  const gaugeColor =
    score >= 70
      ? 'stroke-destructive'
      : score >= 40
        ? 'stroke-amber-400'
        : 'stroke-primary'

  return (
    <div className="relative grid size-44 place-items-center">
      <svg viewBox="0 0 140 140" className="size-44 -rotate-90">
        <circle
          cx="70"
          cy="70"
          r={radius}
          fill="none"
          stroke="var(--color-muted)"
          strokeWidth="11"
        />
        <circle
          cx="70"
          cy="70"
          r={radius}
          fill="none"
          className={cn(gaugeColor, 'transition-[stroke-dasharray] duration-1000 ease-out')}
          strokeWidth="11"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circumference}`}
        />
      </svg>
      <div className="absolute flex flex-col items-center text-center">
        <span className="font-heading text-4xl font-semibold tracking-tight">{score}%</span>
        <span className="mt-0.5 text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Risk Score
        </span>
      </div>
    </div>
  )
}

export default function AnalysisResultsPage() {
  const [data] = useState<AnalysisResult>(MOCK_ANALYSIS_DATA)
  const [expandedFindings, setExpandedFindings] = useState<Record<string, boolean>>({
    'find-1': true, // Keep first finding open by default
  })

  const toggleFinding = (id: string) => {
    setExpandedFindings((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  // Trigger download (Pre-configured for future GET /download-audit-report integration)
  const handleDownloadReport = () => {
    alert('Simulating report download from endpoint: GET /download-audit-report')
  }

  return (
    <DashboardShell>
      <div className="mx-auto max-w-5xl space-y-8">
        {/* 1. Page Header & Top Actions */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium',
                  statusBadgeStyles[data.overall_status],
                )}
              >
                <CheckCircle2 className="size-3.5" />
                Analysis Completed
              </span>
            </div>
            <h1 className="mt-2 font-heading text-2xl font-semibold tracking-tight md:text-3xl">
              Analysis Complete
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Your document has been successfully analyzed. Review the detected risks and detailed findings below.
            </p>
          </div>

          {/* Top Actions */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <Button
              onClick={handleDownloadReport}
              className="h-10 gap-2 px-4 text-xs font-medium shadow-[0_0_24px_-8px_var(--color-primary)]"
            >
              <Download className="size-4" />
              Download Report
            </Button>
            <Button
              variant="outline"
              nativeButton={false}
              render={<Link href="/dashboard/scan" />}
              className="h-10 gap-2 px-4 text-xs font-medium border-border/80"
            >
              <PlusCircle className="size-4" />
              Analyze Another Document
            </Button>
          </div>
        </div>

        {/* 2. Analyzed Document Information Card */}
        <div className="relative overflow-hidden rounded-2xl border border-border/70 bg-card/60 p-5 backdrop-blur-sm md:p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="grid size-12 shrink-0 place-items-center rounded-xl border border-primary/30 bg-primary/15 text-primary">
                <FileText className="size-6" />
              </div>
              <div className="min-w-0">
                <p className="truncate font-heading text-base font-medium text-foreground">
                  {data.filename}
                </p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  PDF Document • {data.file_size} • Completed {data.completed_at}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-6 border-t border-border/50 pt-3 sm:border-t-0 sm:pt-0">
              <div>
                <p className="text-[11px] text-muted-foreground">Figures Analyzed</p>
                <p className="font-heading text-sm font-semibold">{data.figures_analyzed}</p>
              </div>
              <div className="h-8 w-px bg-border/60" />
              <div>
                <p className="text-[11px] text-muted-foreground">Text Passages</p>
                <p className="font-heading text-sm font-semibold">{data.text_passages_analyzed}</p>
              </div>
            </div>
          </div>
        </div>

        {/* 3 & 4. Overall Risk Score Hero + Risk Breakdown */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Hero Risk Score Gauge */}
          <div className="flex flex-col items-center justify-center rounded-2xl border border-border/70 bg-card/50 p-6 text-center backdrop-blur-sm lg:col-span-1">
            <h3 className="font-heading text-base font-semibold">Overall Risk Score</h3>
            <p className="mt-0.5 text-xs text-muted-foreground">Combined forensic indicators</p>

            <div className="my-5">
              <RiskGauge score={data.overall_score} />
            </div>

            <span
              className={cn(
                'inline-flex rounded-full border px-3.5 py-1 text-xs font-semibold uppercase tracking-wider',
                statusBadgeStyles[data.overall_status],
              )}
            >
              {data.overall_status}
            </span>
          </div>

          {/* Risk Breakdown Cards */}
          <div className="grid gap-4 sm:grid-cols-3 lg:col-span-2">
            {/* Text Risk Card */}
            <div className="flex flex-col justify-between rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm">
              <div>
                <div className="flex items-center justify-between">
                  <span className="grid size-9 place-items-center rounded-lg border border-primary/25 bg-primary/10 text-primary">
                    <FileSearch className="size-4" />
                  </span>
                  <span className="font-heading text-xl font-semibold">{data.text_risk}%</span>
                </div>
                <h4 className="mt-4 font-heading text-sm font-semibold">Text Similarity Risk</h4>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  Potentially similar or suspicious textual content detected across global databases.
                </p>
              </div>
              <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-primary"
                  style={{ width: `${data.text_risk}%` }}
                />
              </div>
            </div>

            {/* Visual Risk Card */}
            <div className="flex flex-col justify-between rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm">
              <div>
                <div className="flex items-center justify-between">
                  <span className="grid size-9 place-items-center rounded-lg border border-amber-400/25 bg-amber-400/10 text-amber-300">
                    <Images className="size-4" />
                  </span>
                  <span className="font-heading text-xl font-semibold text-amber-300">
                    {data.image_risk}%
                  </span>
                </div>
                <h4 className="mt-4 font-heading text-sm font-semibold">Visual Similarity Risk</h4>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  Potentially duplicated or visually similar figures and charts detected.
                </p>
              </div>
              <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-amber-400"
                  style={{ width: `${data.image_risk}%` }}
                />
              </div>
            </div>

            {/* Overall Assessment Summary */}
            <div className="flex flex-col justify-between rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm">
              <div>
                <div className="flex items-center justify-between">
                  <span className="grid size-9 place-items-center rounded-lg border border-primary/25 bg-primary/10 text-primary">
                    <ShieldAlert className="size-4" />
                  </span>
                  <span className="font-heading text-xs font-semibold text-muted-foreground">
                    Status
                  </span>
                </div>
                <h4 className="mt-4 font-heading text-sm font-semibold">Overall Assessment</h4>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  The document contains multiple findings that require manual verification before approval.
                </p>
              </div>
              <div className="mt-4">
                <span className="text-xs font-medium text-amber-300">Requires Review</span>
              </div>
            </div>
          </div>
        </div>

        {/* 5. Analysis Statistics Section */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm">
            <div className="flex items-center gap-3 text-muted-foreground">
              <Images className="size-4 text-primary" />
              <span className="text-xs">Figures Extracted</span>
            </div>
            <p className="mt-3 font-heading text-2xl font-semibold tracking-tight">
              {data.figures_analyzed}
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground/70">Isolated diagram objects</p>
          </div>

          <div className="rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm">
            <div className="flex items-center gap-3 text-muted-foreground">
              <Layers className="size-4 text-primary" />
              <span className="text-xs">Text Passages</span>
            </div>
            <p className="mt-3 font-heading text-2xl font-semibold tracking-tight">
              {data.text_passages_analyzed}
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground/70">Indexed semantic blocks</p>
          </div>

          <div className="rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm">
            <div className="flex items-center gap-3 text-muted-foreground">
              <AlertTriangle className="size-4 text-amber-300" />
              <span className="text-xs">Potential Issues</span>
            </div>
            <p className="mt-3 font-heading text-2xl font-semibold tracking-tight text-amber-300">
              {data.potential_issues_count}
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground/70">Flagged for inspection</p>
          </div>

          <div className="rounded-2xl border border-border/70 bg-card/50 p-5 backdrop-blur-sm">
            <div className="flex items-center gap-3 text-muted-foreground">
              <Clock className="size-4 text-primary" />
              <span className="text-xs">Analysis Duration</span>
            </div>
            <p className="mt-3 font-heading text-2xl font-semibold tracking-tight">
              {data.analysis_duration}
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground/70">Total processing speed</p>
          </div>
        </div>

        {/* 6. Detailed Findings Section */}
        <div className="rounded-2xl border border-border/70 bg-card/50 p-6 backdrop-blur-sm space-y-5">
          <div>
            <h3 className="font-heading text-lg font-semibold">Detected Findings</h3>
            <p className="text-sm text-muted-foreground">
              Itemized matches across visual and textual heuristic dimensions.
            </p>
          </div>

          <div className="space-y-3">
            {data.findings.map((finding) => {
              const isOpen = expandedFindings[finding.id]
              return (
                <div
                  key={finding.id}
                  className="rounded-xl border border-border/60 bg-background/40 transition-colors hover:border-border"
                >
                  <div
                    onClick={() => toggleFinding(finding.id)}
                    className="flex cursor-pointer items-center justify-between gap-4 p-4"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span
                        className={cn(
                          'grid size-8 shrink-0 place-items-center rounded-lg border text-xs font-semibold',
                          statusBadgeStyles[finding.riskLevel],
                        )}
                      >
                        {finding.type === 'Visual Similarity' ? (
                          <Images className="size-4" />
                        ) : (
                          <FileSearch className="size-4" />
                        )}
                      </span>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-heading text-sm font-medium text-foreground">
                            {finding.type}
                          </p>
                          <span
                            className={cn(
                              'rounded-full border px-2 py-0.5 text-[10px] font-medium',
                              statusBadgeStyles[finding.riskLevel],
                            )}
                          >
                            {finding.riskLevel}
                          </span>
                        </div>
                        <p className="truncate text-xs text-muted-foreground">{finding.summary}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 shrink-0">
                      <span className="hidden text-xs font-medium tabular-nums text-muted-foreground sm:inline-block">
                        Similarity: <span className="text-foreground">{finding.similarity}%</span>
                      </span>
                      <button
                        type="button"
                        aria-label="Toggle details"
                        className="grid size-8 place-items-center rounded-lg text-muted-foreground hover:bg-muted"
                      >
                        {isOpen ? <ChevronUp className="size-4" /> : <ChevronDown className="size-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Expandable Details Pane */}
                  {isOpen && (
                    <div className="border-t border-border/40 bg-card/30 p-4 text-xs leading-relaxed space-y-3">
                      <p className="text-muted-foreground">{finding.details}</p>

                      {finding.source && (
                        <div className="flex items-center gap-2 text-primary">
                          <ExternalLink className="size-3.5 shrink-0" />
                          <span className="font-mono text-[11px] underline truncate">
                            Matched Source: {finding.source}
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* 7. Recommended Actions */}
        <div className="rounded-2xl border border-border/70 bg-card/50 p-6 backdrop-blur-sm space-y-4">
          <h3 className="font-heading text-lg font-semibold">Recommended Next Steps</h3>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="flex items-start gap-3 rounded-xl border border-border/50 bg-background/30 p-4">
              <CheckSquare className="size-4 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-medium">Review High-Risk Figures Manually</p>
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  Cross-examine Figure 3 with original citation sources to rule out accidental duplicate submission.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-xl border border-border/50 bg-background/30 p-4">
              <CheckSquare className="size-4 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-medium">Verify Paraphrased Passages</p>
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  Add explicit block quotations in Section 4.2 to attribute unoriginal text blocks correctly.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-xl border border-border/50 bg-background/30 p-4">
              <CheckSquare className="size-4 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-medium">Export Evidence Audit Trail</p>
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  Download the complete forensic PDF report for record keeping and institutional compliance.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-xl border border-border/50 bg-background/30 p-4">
              <CheckSquare className="size-4 text-primary shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-medium">Compare with External Sources</p>
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  Use match links within the expanded finding cards to review referenced preprints.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 8. Forensic Audit Report Prominent Download Card */}
        <div className="relative overflow-hidden rounded-2xl border border-primary/30 bg-card/80 p-6 backdrop-blur-sm shadow-[0_0_30px_-10px_var(--color-primary)]">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div className="max-w-xl">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                <Sparkles className="size-3.5" />
                Forensic Artifact
              </span>
              <h3 className="mt-3 font-heading text-xl font-semibold">Detailed Forensic Audit Report</h3>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                Download a comprehensive evidence report containing image overlay comparisons, detailed line-by-line textual matches, and confidence breakdown scores ready for publication compliance.
              </p>
            </div>

            <Button
              onClick={handleDownloadReport}
              className="h-12 gap-2 px-6 text-xs font-medium shadow-[0_0_20px_-5px_var(--color-primary)] shrink-0"
            >
              <Download className="size-4" />
              Download Audit Report
            </Button>
          </div>
        </div>

        {/* 9. Bottom Navigation Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-border/60">
          <p className="text-xs text-muted-foreground">
            Analysis ID: <span className="font-mono text-foreground">gs_scan_9842013x</span>
          </p>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              nativeButton={false}
              render={<Link href="/dashboard/scan" />}
              className="h-10 gap-2 px-4 text-xs font-medium"
            >
              <PlusCircle className="size-4" />
              Analyze Another Document
            </Button>
            <Button
              onClick={handleDownloadReport}
              className="h-10 gap-2 px-4 text-xs font-medium"
            >
              <Download className="size-4" />
              Download Report
            </Button>
          </div>
        </div>
      </div>
    </DashboardShell>
  )
}