'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import type { ReactNode } from 'react'
import {
  LayoutDashboard,
  FilePlus2,
  History,
  FileText,
  Settings,
  Shield,
} from 'lucide-react'

import { cn } from '@/lib/utils'

interface DashboardShellProps {
  children: ReactNode
}

const navigation = [
  {
    name: 'Dashboard',
    href: '/dashboard',
    icon: LayoutDashboard,
  },
  {
    name: 'New Scan',
    href: '/dashboard/scan',
    icon: FilePlus2,
  },
  {
    name: 'Scan History',
    href: '/dashboard/history',
    icon: History,
  },
  {
    name: 'Reports',
    href: '/dashboard/reports',
    icon: FileText,
  },
]

export function DashboardShell({ children }: DashboardShellProps) {
  const pathname = usePathname()

  return (
    <div className="min-h-screen bg-background text-foreground">

      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-border bg-card/60 backdrop-blur-xl md:flex md:flex-col">

        {/* Logo */}
        <div className="flex h-16 items-center gap-3 border-b border-border px-6">
          <div className="grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground">
            <Shield className="size-5" />
          </div>

          <div>
            <h1 className="font-heading text-lg font-semibold">
              GraphShield
            </h1>

            <p className="text-[10px] text-muted-foreground">
              Intelligent Analysis
            </p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-2 p-4">
          {navigation.map((item) => {
            const Icon = item.icon

            const isActive =
              pathname === item.href ||
              (item.href !== '/dashboard' &&
                pathname.startsWith(item.href))

            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  'flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-all duration-200',
                  isActive
                    ? 'bg-primary/15 text-primary border border-primary/20'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                )}
              >
                <Icon className="size-4" />
                {item.name}
              </Link>
            )
          })}
        </nav>

        {/* Settings */}
        <div className="border-t border-border p-4">
          <Link
            href="/dashboard/settings"
            className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-muted-foreground transition-all hover:bg-muted hover:text-foreground"
          >
            <Settings className="size-4" />
            Settings
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="min-h-screen md:ml-64">

        {/* Mobile Header */}
        <div className="flex h-16 items-center border-b border-border px-5 md:hidden">
          <div className="flex items-center gap-2">
            <Shield className="size-6 text-primary" />

            <span className="font-heading text-lg font-semibold">
              GraphShield
            </span>
          </div>
        </div>

        {/* Page */}
        <div className="p-5 md:p-8 lg:p-10">
          {children}
        </div>

      </main>
    </div>
  )
}